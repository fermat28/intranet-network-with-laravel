package com.ebanga.entrai;

import java.util.Scanner;

public class concours {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char[][] triangle;
		char symbole;
		int nbLigne;
		String Etoiles;

		System.out.print("Quel symbole voulez-vous pour les �pines du sapin? ");
		symbole = sc.nextLine().charAt(0);
		do {
			System.out.print("Combien de ligne (de 8 a 35)? ");
			nbLigne = sc.nextInt();
		} while (nbLigne < 8 || nbLigne > 35);
		do {
			System.out.print(
					"Quelles guirlandes voulez-vous mettre " + "(taille de 3 a 25 caract�res et elles ne peuvent \n"
							+ "pas contenir le m�me caract�re que celui utilis� pour les �pines)?0-0 ");
			Etoiles = sc.next();
		} while (Etoiles.length() < 3 || Etoiles.length() > 25 || Etoiles.contains(Character.toString(symbole)));

		System.out.println();

		// on initialise seulement le nombre de lignes que contiendra ce tableau
		// (ligne), on pourra ensuite
		// choisir � chaque ligne le nombre d'�l�ments (colonne)
		triangle = new char[nbLigne][];
		TrianglePlein(triangle, symbole);
		mettreEtoiles(triangle, Etoiles);
		afficherTriangle(triangle);
		afficherTronc(triangle.length);

	}

	static void TrianglePlein(char[][] triangle, char c) {
		int nbLigne = triangle.length;
		int nbColonne;

		for (int i = 0; i < nbLigne; ++i) {
			nbColonne = i * 2 + 1;
			triangle[i] = new char[nbColonne];
			for (int j = 0; j < nbColonne; ++j) {
				triangle[i][j] = c;
			}
		}
	}

	static void mettreEtoiles(char[][] sapinTriangle, String guirlande) {
		int nbLigne = sapinTriangle.length;

		int pointeurChar = 0;
		int longueurChaine = guirlande.length();

		boolean completerEtoiles = false;

		int i = 0;
		int j = 0;

		while (i < nbLigne) {

			if (i % 2 == 1 || completerEtoiles) {

				sapinTriangle[i][j] = guirlande.charAt(pointeurChar);
				pointeurChar = (pointeurChar + 1) % longueurChaine;

				if ((j >= sapinTriangle[i].length - 1 && pointeurChar != 0) || completerEtoiles) {

					if (pointeurChar == 0) {
						completerEtoiles = false;
						j += random() + 1;
					} else {

						if (!completerEtoiles) {
							completerEtoiles = true;
							++i;
							if (i < nbLigne) {
								j = sapinTriangle[i].length - 1;
							}
						} else if (i % 2 == 0) {
							--j;
							if (j < 0) {
								++i;
								j = 0;
							}
						} else {
							++j;
							if (j >= sapinTriangle[i].length) {
								++i;
								if (i < nbLigne) {
									j = sapinTriangle[i].length - 1;
								}
							}
						}
					}
				} else {

					if (pointeurChar == 0) {
						j += random();
					}
					++j;
				}

				if (i < nbLigne && j >= sapinTriangle[i].length && pointeurChar == 0) {
					++i;
					j = 0;
				}
			} else {

				j = 0;
				++i;
			}
		}
	}

	static void afficherTriangle(char[][] triangle) {
		int nbLigne = triangle.length;
		int nbColonne;
		int nbEspace;

		for (int i = 0; i < nbLigne; ++i) {

			nbEspace = ((2 * nbLigne - 1) - (2 * i + 1)) / 2;
			for (int j = 0; j < nbEspace; ++j) {
				System.out.print(" ");
			}

			nbColonne = triangle[i].length;
			for (int j = 0; j < nbColonne; ++j) {
				System.out.print(triangle[i][j]);
			}

			System.out.println();
		}
	}

	static void afficherTronc(int nbLigne) {
		int largeur;
		int hauteur;

		largeur = (nbLigne * 2 - 1) / 5;
		if (largeur % 2 == 0)
			++largeur;
		hauteur = Math.max(1, nbLigne / 3);

		for (int i = 0; i < hauteur; ++i) {
			for (int j = 0; j < ((nbLigne * 2 - 1) - 3) / 2; ++j)
				System.out.print(" ");
			for (int j = 0; j < largeur; ++j)
				System.out.print("|");
			System.out.println();
		}
	}

	static int random() {
		int val = (int) (Math.random() * 2);
		return (val + 2);
	}

}
