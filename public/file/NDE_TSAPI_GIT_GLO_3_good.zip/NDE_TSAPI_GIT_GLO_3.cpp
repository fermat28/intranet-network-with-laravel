//Nom: NDE TSAPI STEVE-ROLAND
//FILIERE: GIT/GLO III 

#include <iostream>
#include <vector>
#include <sstream>

using namespace std;

vector<int> indicesTab(int* nums, int target, int length) {

    vector<int> indices{};
    
    for (int i = 0; i < length - 1; i++)
    {
        for (int j = 1; j < length; j++)
        {
            if ((nums[i] + nums[j]) == target)
            {
                indices.push_back(i);
                indices.push_back(j);

                break;
            }

        }

        if (indices.size() == 2) {
            break;
        }
    }

    return indices;
}

void N_et_M(string n_m) {

    string str_firstNumber{}, str_secondNumber{};
    int firstNumber{}, secondNumber{};
    int i{};

    //Convertir les string en int
    stringstream ss{};

    while (i < n_m.length() &&  n_m[i] != '&')
    {
        if (n_m[i] != ' ') {
            str_firstNumber += n_m[i];
        }

        i++;
    }

    i++;
    while (i < n_m.length())
    {
        if (n_m[i] != ' ')
            str_secondNumber += n_m[i];
        i++;
    }


    //Convertitions des strings en int

    ss << str_firstNumber;
    ss >> firstNumber;
    

    stringstream ss2{};
    ss2 << str_secondNumber;
    ss2 >> secondNumber;

    int result = firstNumber * secondNumber + firstNumber;

    cout << "Output : " << result << endl;

}

int main()
{
    
    cout << "****Exercice 1**** "  << endl;
    cout << "Test fonction *indicesTab*  : Input [3,2,4] , target = 6" << endl;
    int tab[3]{};
    tab[0] = 3;
    tab[1] = 2;
    tab[2] = 4;

    vector<int> ind = indicesTab(tab, 6, 3);
    cout << "Ouput : " << "[" << ind[0] << "," << ind[1] << "]" << endl;


    cout << "****Exercice 2****" << endl;
    cout << "Test fonction *N_M*  : Input '7 & 13' " << endl;
    N_et_M("7 & 13");

}
