

		
		// KEMMEGNE EMERICK TOUNSI 

package com.enspd.dev.battle;

public class DevClass {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub

		
		
		System.out.println("DEV battle ");
		

		System.out.println(" ***********************EXERCICE 4 ***********************  ");
		
		System.out.println("");
		
		String [] tab = {"     ", "    " , "   ", "  " , " " };
		

		int p = 0;
		for (int i = 0; i < 9; i++) {
			
			if(i % 2 == 0) {
				System.out.print(tab[p]);
				p++;
				for (int j = 0; j <= i; j++) {
					
					System.out.print("*");	
					
				}


				System.out.println();
				
				
			}
			
		}
		

	


		System.out.println(" ***********************EXERCICE 5 ***********************  ");
		
		String mot = new String("bab");
		
		
		
		System.out.println(isPalindromme("xsz"));
		
		
		
		
		
		
		
		
		
		
}
	
	public static String motPalindromme(String mot) {
		
		int j = mot.length() - 1;
		
		for (int i = 0; i < mot.length(); i++) {
			
			isPalindromme(mot.substring(i, j));
		
			}
	
		return " ";
	}
		
	
		
	
	public static boolean isPalindromme(String mot) {
		
		int j = mot.length() - 1;
	for (int i = 0; i < mot.length(); i++) {
		
		if(mot.charAt(i) != mot.charAt(j)){
			return false;
		}
		
		if(i == j) {
			return true;	
		}
		
		j--;
	
		}
		return true;
	}
	
	
	
	
	
	
	


}
