#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main(int argc, char** argv) {
	
	//Exo1
	int n = 4;
	int nums[n] = {2,7,11,15};
	int cible = 9;
	int som, i, j = 0;
	for(i=0; i<n; i++){
		for(j=i+1; j<n; j++){
			som = nums[i] + nums[j];
			if(som == cible){
				printf("[%d,%d]",i,j);
				return j;
			}
		}
	}
	
	return 0;
}
